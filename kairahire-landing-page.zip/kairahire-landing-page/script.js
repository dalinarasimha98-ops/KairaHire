// KairaHire landing page interactions

document.addEventListener('DOMContentLoaded', function () {

  // ===== Contact form handling =====
  const form = document.getElementById('leadForm');
  const note = document.getElementById('formNote');

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      const name = document.getElementById('name').value.trim();
      const company = document.getElementById('company').value.trim();
      const email = document.getElementById('email').value.trim();
      const role = document.getElementById('role').value.trim();

      if (!name || !company || !email) {
        note.textContent = 'Please fill in your name, company and email.';
        note.style.color = '#bd6535';
        return;
      }

      // Build a mailto fallback so the lead reaches the inbox directly.
      const subject = encodeURIComponent('New hiring requirement — ' + company);
      const body = encodeURIComponent(
        'Name: ' + name + '\n' +
        'Company: ' + company + '\n' +
        'Email: ' + email + '\n' +
        'Role: ' + (role || 'Not specified') + '\n'
      );
      const mailto = 'mailto:info@kairahire.com?subject=' + subject + '&body=' + body;

      window.location.href = mailto;

      note.textContent = 'Opening your email client to send this through — thank you!';
      note.style.color = '#7c9082';
      form.reset();
    });
  }

  // ===== Sticky header background swap on scroll (subtle) =====
  const header = document.querySelector('.site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 12) {
        header.style.boxShadow = '0 1px 0 rgba(0,0,0,0.04)';
      } else {
        header.style.boxShadow = 'none';
      }
    }, { passive: true });
  }

  // ===== Reveal-on-scroll for ledger rows and problem cards =====
  const revealTargets = document.querySelectorAll('.ledger-row, .problem-card, .how-step, .service-row');
  if ('IntersectionObserver' in window && revealTargets.length) {
    revealTargets.forEach(function (el) {
      el.classList.add('reveal');
    });

    const io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry, i) {
        if (entry.isIntersecting) {
          const el = entry.target;
          setTimeout(function () {
            el.classList.add('reveal-in');
          }, i * 40);
          io.unobserve(el);
        }
      });
    }, { threshold: 0.1 });

    revealTargets.forEach(function (el) { io.observe(el); });

    // Safety net: ensure everything is visible after a short delay regardless
    setTimeout(function () {
      revealTargets.forEach(function (el) { el.classList.add('reveal-in'); });
    }, 1500);
  }

});
